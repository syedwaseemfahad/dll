package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem.Product;

public class Bike extends Vehicle {
}
