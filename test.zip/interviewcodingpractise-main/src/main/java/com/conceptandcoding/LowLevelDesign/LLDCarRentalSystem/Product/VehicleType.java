package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem.Product;

public enum VehicleType {
    CAR;
}
