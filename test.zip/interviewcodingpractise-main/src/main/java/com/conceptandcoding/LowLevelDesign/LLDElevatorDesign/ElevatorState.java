package com.conceptandcoding.LowLevelDesign.LLDElevatorDesign;

public enum ElevatorState {
    MOVING,
    IDLE;
}
