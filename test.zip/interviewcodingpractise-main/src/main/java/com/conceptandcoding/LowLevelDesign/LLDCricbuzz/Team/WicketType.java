package com.conceptandcoding.LowLevelDesign.LLDCricbuzz.Team;

public enum WicketType {

    RUNOUT,
    BOLD,
    CATCH;
}
