package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem.Product;

public class Car extends Vehicle{

}
