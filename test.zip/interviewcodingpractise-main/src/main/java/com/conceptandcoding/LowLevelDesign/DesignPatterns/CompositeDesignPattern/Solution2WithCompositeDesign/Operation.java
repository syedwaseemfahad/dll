package com.conceptandcoding.LowLevelDesign.DesignPatterns.CompositeDesignPattern.Solution2WithCompositeDesign;

public enum Operation {

    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE;
}
