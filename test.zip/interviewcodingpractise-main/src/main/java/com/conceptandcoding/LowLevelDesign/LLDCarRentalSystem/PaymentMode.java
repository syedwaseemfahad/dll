package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem;

public enum PaymentMode {

    CASH,
    ONLINE;
}
