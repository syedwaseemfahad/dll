package com.conceptandcoding.LowLevelDesign.LLDSnakeLadder;

public class Cell {
    Jump jump;
    //getters and setters
}
