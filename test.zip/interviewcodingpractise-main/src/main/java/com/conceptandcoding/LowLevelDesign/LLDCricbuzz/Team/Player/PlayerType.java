package com.conceptandcoding.LowLevelDesign.LLDCricbuzz.Team.Player;

public enum PlayerType {

    BATSMAN,
    BOWLER,
    WICKETKEEPER,
    CAPTAIN,
    ALLROUNDER;
}

