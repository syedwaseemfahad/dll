package com.conceptandcoding.LowLevelDesign.DesignPatterns.FlyWeightPattern;

public interface IRobot {

    public void display(int x, int y);
}
