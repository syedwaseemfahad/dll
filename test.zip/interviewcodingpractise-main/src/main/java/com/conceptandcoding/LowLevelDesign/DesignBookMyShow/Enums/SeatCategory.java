package com.conceptandcoding.LowLevelDesign.DesignBookMyShow.Enums;

public enum SeatCategory {

    SILVER,
    GOLD,
    PLATINUM;
}
