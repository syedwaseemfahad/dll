package com.conceptandcoding.LowLevelDesign.LLDTicTacToe.Model;

public class PlayingPiece {

    public PieceType pieceType;

    PlayingPiece(PieceType pieceType) {
        this.pieceType = pieceType;
    }
}
