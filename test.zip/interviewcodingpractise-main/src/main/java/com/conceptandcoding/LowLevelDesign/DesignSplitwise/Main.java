package com.conceptandcoding.LowLevelDesign.DesignSplitwise;

public class Main {

    public static void main(String args[]){

        Splitwise splitwise = new Splitwise();
        splitwise.demo();
    }
}
