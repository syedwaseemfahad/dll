package com.conceptandcoding.LowLevelDesign.LLDCricbuzz;

public interface MatchType {
    public int noOfOvers();
    public int maxOverCountBowlers();
}
