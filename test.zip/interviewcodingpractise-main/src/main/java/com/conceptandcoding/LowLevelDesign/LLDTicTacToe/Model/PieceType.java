package com.conceptandcoding.LowLevelDesign.LLDTicTacToe.Model;

public enum PieceType {
    X,
    O;
}
