package com.conceptandcoding.LowLevelDesign.LLDCricbuzz.Team.Player.Score;

public class BowlingScoreCard {
    public int totalOversCount;
    public int runsGiven;
    public int wicketsTaken;
    public int noBallCount;
    public int wideBallCount;
    public double economyRate;
}
