package com.conceptandcoding.LowLevelDesign.LLDCricbuzz.Inning;

public enum BallType {

    NORMAL,
    WIDEBALL,
    NOBALL;
}
